
/**
 * CEN 3024-13038 - Software Development 1
 * October 2026
 * Class: ConsoleUI
 * Objective: Provides the command-line interface for the DWMA Soul Mission Management System.
 * Allows users to add, import, display, search, update, delete, and calculate qualification progress for records.
 * User input is validated to prevent invalid input from crashing the application.
 */

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Scanner;

public class ConsoleUI {

    private final Scanner scanner;
    private final RecordManager recordManager;
    private final InputValidator inputValidator;
    private final ProgressCalculator progressCalculator;
    private final FileImporter fileImporter;

    private boolean running;

    public ConsoleUI() {
        scanner = new Scanner(System.in);
        recordManager = new RecordManager();
        inputValidator = new InputValidator();
        progressCalculator = new ProgressCalculator();
        fileImporter = new FileImporter(inputValidator);
        running = true;
    }

    public void start() {
        System.out.println("==============================================");
        System.out.println("  DWMA SOUL MISSION MANAGEMENT SYSTEM");
        System.out.println("==============================================");

        while (running) {
            displayMenu();
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    addRecord();
                    break;
                case 2:
                    importRecords();
                    break;
                case 3:
                    displayAllRecords();
                    break;
                case 4:
                    searchById();
                    break;
                case 5:
                    searchByTeamName();
                    break;
                case 6:
                    updateRecord();
                    break;
                case 7:
                    deleteRecord();
                    break;
                case 8:
                    calculateProgress();
                    break;
                case 9:
                    exitApplication();
                    break;
                default:
                    System.out.println(
                            "Invalid menu choice. Please select 1-9.");
            }
        }
    }

    private void displayMenu() {
        System.out.println();
        System.out.println("**************** MAIN MENU ****************");
        System.out.println("1. Add a Record Manually");
        System.out.println("2. Import Records from a Text File");
        System.out.println("3. Display All Records");
        System.out.println("4. Search by Record ID");
        System.out.println("5. Search by Team Name");
        System.out.println("6. Update a Record");
        System.out.println("7. Delete a Record");
        System.out.println("8. Calculate Qualification Progress");
        System.out.println("9. Exit");
        System.out.println("********************************************");
    }

    private int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println(
                        "Invalid input. Please enter a whole number.");
            }
        }
    }

    private int readRecordId(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();

            String error = inputValidator.validateRecordId(input);

            if (!error.isEmpty()) {
                System.out.println("Error: " + error);
                continue;
            }

            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println(
                        "Invalid record ID. Please try again.");
            }
        }
    }

    private String readTeamName() {
        while (true) {
            System.out.print("Enter team name: ");
            String name = scanner.nextLine().trim();

            String error = inputValidator.validateTeamName(name);

            if (!error.isEmpty()) {
                System.out.println("Error: " + error);
                continue;
            }

            // Reject names containing digits.
            if (name.matches(".*\\d.*")) {
                System.out.println(
                        "Error: Team name cannot contain numbers.");
                continue;
            }
            return name;
        }
    }

    private String readPartnerType() {
        while (true) {
            System.out.println("Partner types: Weapon, Meister, Team");
            System.out.print("Enter partner type: ");
            String type = scanner.nextLine().trim();

            String error = inputValidator.validatePartnerType(type);

            if (error.isEmpty()) {
                if (type.equalsIgnoreCase("weapon")) {
                    return "Weapon";
                } else if (type.equalsIgnoreCase("meister")) {
                    return "Meister";
                } else {
                    return "Team";
                }
            }

            System.out.println("Error: " + error);
        }
    }

    private int readSoulCount(String prompt) {
        while (true) {
            int count = readInt(prompt);

            String error = inputValidator.validateSoulCount(count);

            if (error.isEmpty()) {
                return count;
            }

            System.out.println("Error: " + error);
        }
    }

    private double readTrainingLevel() {
        while (true) {
            System.out.print("Enter training level (1.0-100.0): ");
            String input = scanner.nextLine().trim();

            try {
                double level = Double.parseDouble(input);

                String error =
                        inputValidator.validateTrainingLevel(level);

                if (error.isEmpty()) {
                    return level;
                }

                System.out.println("Error: " + error);
            } catch (NumberFormatException e) {
                System.out.println(
                        "Invalid training level. Enter a number.");
            }
        }
    }

    private boolean readActiveStatus() {
        while (true) {
            System.out.print("Is the team active? (true/false): ");
            String input = scanner.nextLine().trim();

            if (input.equalsIgnoreCase("true")) {
                return true;
            }

            if (input.equalsIgnoreCase("false")) {
                return false;
            }

            System.out.println(
                    "Invalid status. Enter true or false.");
        }
    }

    private LocalDate readMissionDate() {
        while (true) {
            System.out.print(
                    "Enter last mission date (yyyy-MM-dd): ");
            String input = scanner.nextLine().trim();

            String error = inputValidator.validateDate(input);

            if (error.isEmpty()) {
                try {
                    return LocalDate.parse(input);
                } catch (DateTimeParseException e) {
                    System.out.println(
                            "Invalid date. Please try again.");
                }
            } else {
                System.out.println("Error: " + error);
            }
        }
    }

    private SoulMissionRecord readNewRecord() {
        int id = readRecordId("Enter six-digit record ID: ");

        while (recordManager.containsId(id)) {
            System.out.println(
                    "That record ID already exists. Choose another.");
            id = readRecordId("Enter six-digit record ID: ");
        }

        String name = readTeamName();
        String partnerType = readPartnerType();

        int kishinSouls =
                readSoulCount("Enter kishin souls collected: ");

        int witchSouls =
                readSoulCount("Enter witch souls collected: ");

        double trainingLevel = readTrainingLevel();
        boolean active = readActiveStatus();
        LocalDate missionDate = readMissionDate();

        return new SoulMissionRecord(
                id,
                name,
                partnerType,
                kishinSouls,
                witchSouls,
                trainingLevel,
                active,
                missionDate
        );
    }

    private void addRecord() {
        System.out.println("\n--- ADD NEW RECORD ---");

        SoulMissionRecord record = readNewRecord();

        String error = inputValidator.validateRecord(record);

        if (!error.isEmpty()) {
            System.out.println(
                    "Record validation failed: " + error);
            return;
        }

        if (recordManager.addRecord(record)) {
            System.out.println("Record added successfully!");
            System.out.println(record);
        } else {
            System.out.println(
                    "Record could not be added. Check the ID.");
        }
    }

    private void importRecords() {
        System.out.println("\n--- IMPORT RECORDS ---");
        System.out.print("Enter the text file path: ");

        String filePath = scanner.nextLine().trim();

        if (filePath.isEmpty()) {
            System.out.println("Error: File path cannot be blank.");
            return;
        }

        fileImporter.importRecords(filePath, recordManager);
    }

    private void displayAllRecords() {
        System.out.println("\n--- ALL SOUL MISSION RECORDS ---");
        System.out.println(
                "Total records: " + recordManager.getRecordCount());

        recordManager.getAllRecords();
    }

    private void searchById() {
        System.out.println("\n--- SEARCH BY RECORD ID ---");

        int id = readRecordId("Enter record ID: ");
        SoulMissionRecord record = recordManager.findById(id);

        if (record != null) {
            System.out.println("Record found:");
            System.out.println(record);
        } else {
            System.out.println(
                    "No record found with ID " + id + ".");
        }
    }

    private void searchByTeamName() {
        System.out.println("\n--- SEARCH BY TEAM NAME ---");

        String name = readTeamName();
        SoulMissionRecord record =
                recordManager.findByTeamName(name);

        if (record != null) {
            System.out.println("Record found:");
            System.out.println(record);
        } else {
            System.out.println(
                    "No record found for team \"" + name + "\".");
        }
    }

    private void updateRecord() {
        System.out.println("\n--- UPDATE RECORD ---");

        int id = readRecordId(
                "Enter the ID of the record to update: ");

        SoulMissionRecord existing = recordManager.findById(id);

        if (existing == null) {
            System.out.println("Record not found.");
            return;
        }

        System.out.println("Current record:");
        System.out.println(existing);

        boolean editing = true;

        while (editing) {
            System.out.println("\nSelect the field to update:");
            System.out.println("1. Team Name");
            System.out.println("2. Partner Type");
            System.out.println("3. Kishin Souls Collected");
            System.out.println("4. Witch Souls Collected");
            System.out.println("5. Training Level");
            System.out.println("6. Active Status");
            System.out.println("7. Last Mission Date");
            System.out.println("8. Finish Updating");

            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    existing.setTeamName(readTeamName());
                    break;
                case 2:
                    existing.setPartnerType(readPartnerType());
                    break;
                case 3:
                    existing.setKishinSoulsCollected(
                            readSoulCount(
                                    "Enter new kishin soul count: "));
                    break;
                case 4:
                    existing.setWitchSoulsCollected(
                            readSoulCount(
                                    "Enter new witch soul count: "));
                    break;
                case 5:
                    existing.setTrainingLevel(readTrainingLevel());
                    break;
                case 6:
                    existing.setActiveStatus(readActiveStatus());
                    break;
                case 7:
                    existing.setLastMissionDate(readMissionDate());
                    break;
                case 8:
                    editing = false;
                    break;
                default:
                    System.out.println(
                            "Invalid choice. Select 1-8.");
            }

            if (editing) {
                String error =
                        inputValidator.validateRecord(existing);

                if (!error.isEmpty()) {
                    System.out.println(
                            "Validation error: " + error);
                } else {
                    recordManager.updateRecord(existing);
                    System.out.println("Current record:");
                    System.out.println(existing);
                }
            }
        }

        String error = inputValidator.validateRecord(existing);

        if (!error.isEmpty()) {
            System.out.println(
                    "Record has invalid data: " + error);
        } else {
            recordManager.updateRecord(existing);
            System.out.println("Record updated successfully!");
            System.out.println(existing);
        }
    }

    private void deleteRecord() {
        System.out.println("\n--- DELETE RECORD ---");

        int id = readRecordId("Enter the ID to delete: ");
        SoulMissionRecord record = recordManager.findById(id);

        if (record == null) {
            System.out.println("Record not found.");
            return;
        }

        System.out.println("Record selected for deletion:");
        System.out.println(record);

        System.out.print(
                "Are you sure you want to delete this record? (yes/no): ");

        String confirmation = scanner.nextLine().trim();

        if (confirmation.equalsIgnoreCase("yes")) {
            if (recordManager.deleteRecord(id)) {
                System.out.println("Record deleted successfully.");
            } else {
                System.out.println(
                        "The record could not be deleted.");
            }
        } else {
            System.out.println("Deletion cancelled.");
        }
    }

    private void calculateProgress() {
        System.out.println(
                "\n--- DEATH SCYTHE QUALIFICATION PROGRESS ---");

        int id = readRecordId(
                "Enter the record ID to calculate progress: ");

        SoulMissionRecord record = recordManager.findById(id);

        if (record == null) {
            System.out.println("Record not found.");
            return;
        }

        System.out.println(
                progressCalculator.createProgressReport(record));
    }

    private void exitApplication() {
        System.out.print(
                "Are you sure you want to exit? (yes/no): ");

        String confirmation = scanner.nextLine().trim();

        if (confirmation.equalsIgnoreCase("yes")) {
            running = false;
            System.out.println(
                    "Exiting DWMA Soul Mission Management System. Goodbye!");
        } else {
            System.out.println("Returning to the main menu.");
        }
    }

    public static void main(String[] args) {
        ConsoleUI consoleUI = new ConsoleUI();
        consoleUI.start();
    }
}
